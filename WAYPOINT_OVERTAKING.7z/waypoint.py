import glob
import os
import sys
import controller
import local_planner
import basic_agent11
from enum import Enum
try:
    sys.path.append(glob.glob('../carla/dist/carla-*%d.%d-%s.egg' % (
        sys.version_info.major,
        sys.version_info.minor,
        'win-amd64' if os.name == 'nt' else 'linux-x86_64'))[0])
except IndexError:
    pass

import carla

import random
import time
#import change_lane

_args_lateral_dict = {'K_P': 1.0, 'K_D': 0.01, 'K_I': 0.0, 'dt': 0.05}
_target_speed = 20
#current_waypoint = self._map.get_waypoint(CarlaDataProvider.get_location(self._actor))
name="/home/aicore/CARLA_PROPERBUILT/carla/PythonAPI/carla/agents/"
#L=True
class RoadOption(Enum):
    """
    RoadOption represents the possible topological configurations when moving from a segment of lane to other.
    """
    VOID = -1
    LEFT = 1
    RIGHT = 2
    STRAIGHT = 3
    LANEFOLLOW = 4
    CHANGELANELEFT = 5
    CHANGELANERIGHT = 6

def lane_change_overtaking(waypoint,player,check=True):
    #print('hello')
    plan=[]
    plan.append((waypoint,RoadOption.LANEFOLLOW))
    print(waypoint.lane_change)
    if check ==True:
        lane_change_possibilites=['Left','Right','Both']
        if str(waypoint.lane_change) not in lane_change_possibilites:
            time.sleep(5)
    target_lane_id = None
    if waypoint.lane_change == 'Left':
        wp_left = player[-1][0].get_left_lane()
        target_lane_id=wp_left.lane_id
        next_wp = wp_left.next(25)
        plan.append(next_wp[0],RoadOption.LANEFOLLOW)
    elif str(waypoint.lane_change) == 'Right':
        #print(waypoint)
        wp_right = plan[-1][0].get_right_lane()
        target_lane_id=wp_right.lane_id
        next_wp = wp_right.next(25)
        #print(len(next_wp))
        #print('hhhhh')
        plan.append((next_wp[0],RoadOption.LANEFOLLOW))
    else:
        print('kkkkk')
        return None
    distance=0
    distance_other_lane=15
    while distance<distance_other_lane:
        next_wp=plan[-1][0].next(2)
        distance+=next_wp[0].transform.location.distance(plan[-1][0].transform.location)
        plan.append((next_wp[0],RoadOption.LANEFOLLOW))
    print(target_lane_id)
    return plan,target_lane_id

def main():
    L=True
    actor_list = []
    try:
        client = carla.Client('localhost', 2000)
        client.set_timeout(2.0)
        world = client.get_world()
        spwan_points=world.get_map().get_spawn_points()
        blueprint_library = world.get_blueprint_library()
        bp = random.choice(blueprint_library.filter('vehicle'))
        car = random.choice(blueprint_library.filter('vehicle.tesla.model3'))
        counter=0
        for i in spwan_points:
            print(counter,i)
            counter+=1
        vehicle1 = world.spawn_actor(car,spwan_points[59])
        vehicle2= world.spawn_actor(car,spwan_points[129])
        #spawn_point1 = carla.Transform(carla.Location(x=44.476279297, y=3.684685059))
        #spawn_point2 = carla.Transform(carla.Location(x=157.377089844, y=5.371150513))
        #x=194.462324219, y=198.759980469
        #x=42.648183594, y=-7.84390564
        #vehicle1 = world.spawn_actor(bp,spawn_point1) #Town 3
        #vehicle2= world.spawn_actor(car,spawn_point2)  #Town 3
        actor_list.append(vehicle1)
        actor_list.append(vehicle2)
        car=vehicle1.get_control()
        waypoint = world.get_map().get_waypoint(vehicle1.get_location())
        print(waypoint.lane_id)
        #print(type(waypoint))
        waypoint.lane_id
        #print(waypoint.lane_change)
        waypoint.lane_change.Right
        if waypoint.lane_change == "Right":
            waypoint.get_right_lane()
            #print(waypoint.get_right_lane())
        else:
            waypoint.get_left_lane()
            #print(waypoint.get_left_lane())
        agent1=basic_agent11.BasicAgent(vehicle1)
        agent2=local_planner.LocalPlanner(vehicle1)
        loc=vehicle1.get_location()
        X=float(round(loc.x,1))
        Y=float(round(loc.y,2))
        while not X == 220.145644531 and not Y==6.308761597:
            #print(X)
            #print(agent2._waypoints_queue)
            waypoint.lane_change
            #agent1.__init__(vehicle1)   #making actor dead check why??
            agent1.set_destination((220.145644531,6.308761597,1.8431))
            #agent1.set_destination((511.50,-135.000,0.5))
            control = agent1.run_step()
            acc=vehicle1.get_acceleration()
            #print(acc)
            #agent1.run_step()
            vehicle1.apply_control(control)
            
            loc1=vehicle1.get_location()
            loc2=vehicle2.get_location()
            calc=loc2-loc1
            #print(calc)
            c=0
            counter1=0
            J=0
            while round(calc.x,0)==30:
                cntl=vehicle1.get_control()
                #print(cntl)
                #cntl.brake=1.0
                vehicle1.apply_control(cntl)
                location=world.get_map().get_waypoint(vehicle1.get_location())
                player=agent2._waypoints_queue
                if c==0:
                    plan,Id=lane_change_overtaking(location,player,check=True)
                    #print(id)
                    c+=1
                while J<=110:
                        print('ffff')
                        agent2.set_global_plan(plan)
                        control1=agent2.run_step()
                        vehicle1.apply_control(control1)
                        J+=1
                if Id ==location.lane_id:
                    print('hiiiiii')
                    location=world.get_map().get_waypoint(vehicle1.get_location())
                    agent1.set_destination((220.145644531,6.308761597,1.8431))
                    control = agent1.run_step()
                    vehicle1.apply_control(control)
                
                #time.sleep(10)
                #print(plan[-1])
                #control = agent1.run_step()
                #cntl.steer=0.06
                #vehicle1.get_map().get_topology()
                #print('hi')
                #print(vehicle1.get_topology()

            X=float(round(loc.x,1))
            #if X == 379.54:
            #time.sleep(5)
            #if control.throttle==0.0 :
             #   car.steer=-0.5
              #  actor_list[0].apply_control(car)
            #print("stop")
            L=False
            #time.sleep(0.2)
        
        print("destination")
        car.throttle=0.0
        car.brake=1.0
        actor_list[0].apply_control(car)
        time.sleep(30)
        #print(vehicle1.get_control())
        '''navi=local_planner.LocalPlanner(vehicle1)
        while True:
            navi.__init__(vehicle1)
            navi._init_controller(_args_lateral_dict)
            navi.run_step()'''
        #waypoint_tuple_list = world.get_map().get_topology()
        #print(waypoint_tuple_list)
        #for i in waypoint_tuple_list:
          #  for j in i:
           #     print(j)
        #print(vehicle.get_location())
        #vehicle.set_simulate_physics(True)
        #print(w)
        #a=controller.VehiclePIDController(vehicle)
        '''while True:
            #print('hi')
            a=controller.VehiclePIDController(vehicle1)
            #waypoint = world.get_map().get_waypoint(vehicle1.get_location())
            wp=random.choice(waypoint.next(2.0))
            #print(wp.transform.location)
            waypoint = world.get_map().get_waypoint(wp.transform.location)
            #print(random.choice(waypoint.next(2.0)))
            a.run_step(20, wp)'''
        '''
        while True:
            #waypoint1=waypoint.next(2.0)
            # Find next waypoint 2 meters ahead.
            waypoint = random.choice(waypoint.next(2.0))
            vehicle.apply_control(carla.VehicleControl(throttle=0.0, brake=0.0))
            vehicle.set_transform(waypoint.transform)
            
            lane_type = waypoint.lane_type
            lane_change = waypoint.lane_change
            print(waypoint.left_lane_marking.lane_change)
            print(lane_change)
            print('moved vehicle to %s' % waypoint.transform)

            world.debug.draw_string(waypoint.transform.location, 'O', draw_shadow=False,
                                            color=carla.Color(r=255, g=0, b=0), life_time=120.0,
                                            persistent_lines=True)
        #location.x += 14.179
            #vehicle.set_location(j.transform.location)
            #print('moved vehicle to %s' % j.transform.location)

            time.sleep(0.1)'''
    finally:

        print('destroying actors')
        for actor in actor_list:
         actor.destroy()
        print('done.')

if __name__ == '__main__':

    main()
