import glob
import os
import sys
try:
    sys.path.append(glob.glob('../carla/dist/carla-*%d.%d-%s.egg' % (
        sys.version_info.major,
        sys.version_info.minor,
        'win-amd64' if os.name == 'nt' else 'linux-x86_64'))[0])
except IndexError:
    pass

import carla

import random
import time
import local_planner
from global_route_planner import GlobalRoutePlanner
from global_route_planner_dao import GlobalRoutePlannerDAO
actor_list=[]
def main():
    try:
        client = carla.Client('localhost', 2000)
        client.set_timeout(2.0)
        world = client.get_world()
        spwan_points=world.get_map().get_spawn_points()
        blueprint_library = world.get_blueprint_library()
        bp = random.choice(blueprint_library.filter('vehicle.bmw.grandtourer'))
        for i in spwan_points:
            #print(i)
            vehicle1 = world.spawn_actor(bp,i)
            actor_list.append(vehicle1)
        car=actor_list[0].get_control()
        waypoint = world.get_map().get_waypoint(actor_list[0].get_location())
        #agent1=basic_agent11.BasicAgent(actor_list[0])
        loc=actor_list[0].get_location()
        map=world.get_map()
        #print(map)
        agent1=local_planner.LocalPlanner(actor_list[0])
        dao = GlobalRoutePlannerDAO(map, 2.0)
        grp = GlobalRoutePlanner(dao)
        grp.setup()

        a = actor_list[0].get_location()
        b = carla.Location(x=1485.40,
                                y=-577.20,
                                z=50.00)
        w1 = grp.trace_route(a, b)
        while True:
            agent1.set_global_plan(w1)
            #agent1.set_destination((503.50,-133.00,50.00))
            control = agent1.run_step()
            #control.steer=0.0
            actor_list[0].apply_control(control)
    finally:

        print('destroying actors')
        for actor in actor_list:
         actor.destroy()
        print('done.')
        

if __name__ == '__main__':

    main()